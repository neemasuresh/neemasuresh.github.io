import pandas as pd
import matplotlib.pyplot as plt

base_path = r"D:/HDLAB/MAINphase1/"

files = {
    "5 MHz": base_path + "fir_output_2MHz.txt",
    "10 MHz": base_path + "fir_output_10MHz.txt",
    "15 MHz": base_path + "fir_output_15MHz.txt",
    "30 MHz": base_path + "fir_output_30MHz.txt",
}

data = {}
for label, path in files.items():
    try:
        df = pd.read_csv(path, sep=r'\s+', skiprows=1, names=["Index", "Input", "Output"])
        data[label] = df
    except FileNotFoundError:
        print(f"⚠️ File not found: {path}")

plt.figure(figsize=(12, 8))

for i, (label, df) in enumerate(data.items(), 1):
    plt.subplot(len(data), 1, i)
    plt.plot(df["Index"], df["Input"], color='blue', linewidth=1, label='Input')
    plt.plot(df["Index"], df["Output"], color='red', linewidth=1, label='Output')

    # Max amplitude points
    max_in_idx = df["Input"].abs().idxmax()
    max_out_idx = df["Output"].abs().idxmax()
    max_in_val = df.loc[max_in_idx, "Input"]
    max_out_val = df.loc[max_out_idx, "Output"]
    max_in_x = df.loc[max_in_idx, "Index"]
    max_out_x = df.loc[max_out_idx, "Index"]

    # Mark and annotate with offset + bounding box
    plt.scatter(max_in_x, max_in_val, color='blue', s=50, zorder=5)
    plt.text(max_in_x, max_in_val + 2000, f"Max In={max_in_val}",
             color='blue', fontsize=9, ha='left', va='bottom',
             bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))

    plt.scatter(max_out_x, max_out_val, color='red', s=50, zorder=5)
    plt.text(max_out_x, max_out_val - 3000, f"Max Out={max_out_val}",
             color='red', fontsize=9, ha='left', va='top',
             bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))

    plt.title(f"FIR Filter Response for {label}")
    plt.xlabel("Sample Index")
    plt.ylabel("Amplitude")
    plt.legend()
    plt.grid(True)

plt.tight_layout()
plt.show()
