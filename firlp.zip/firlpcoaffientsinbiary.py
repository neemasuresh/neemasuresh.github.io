import numpy as np

# -------------------------------------------------------------
# FIR filter specifications
# -------------------------------------------------------------
N = 21                 # Number of taps
Fs = 80e6              # Sampling frequency (80 MSPS)
Fc = 10e6              # Cutoff frequency (10 MHz)

# -------------------------------------------------------------
# Design FIR filter using Hamming window
# -------------------------------------------------------------
h = np.sinc(2 * Fc / Fs * (np.arange(N) - (N - 1) / 2))
h *= np.hamming(N)
h /= np.sum(h)  # Normalize coefficients

# -------------------------------------------------------------
# Convert to Q15 (16-bit signed integer)
# -------------------------------------------------------------
h_q15 = np.round(h * (2**15 - 1)).astype(int)

# Two’s complement binary conversion
def int16_to_bin(x):
    if x < 0:
        x = (1 << 16) + x
    return format(x, '016b')

# Hex conversion
def int16_to_hex(x):
    if x < 0:
        x = (1 << 16) + x
    return format(x, '04X')

h_bin = [int16_to_bin(x) for x in h_q15]
h_hex = [int16_to_hex(x) for x in h_q15]

# -------------------------------------------------------------
# Print coefficients in shell (decimal, hex, binary)
# -------------------------------------------------------------
print("-----------------------------------------------------------")
print(" FIR Low-Pass Filter Coefficients (Q15 Format)")
print("-----------------------------------------------------------")
print(f"{'Index':>5} {'Decimal':>10} {'Hex':>8} {'Binary':>20}")
print("-----------------------------------------------------------")

for i, (dec, hx, bn) in enumerate(zip(h_q15, h_hex, h_bin)):
    print(f"{i:5d} {dec:10d}  0x{hx:<6}  {bn}")

print("-----------------------------------------------------------")

# -------------------------------------------------------------
# Save binary coefficients to file
# -------------------------------------------------------------
with open("coeff_bin.txt", "w") as f:
    for b in h_bin:
        f.write(b + "\n")

print("\nBinary coefficient file 'coeff_bin.txt' generated successfully!")
