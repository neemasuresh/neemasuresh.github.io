
  `timescale 1ns/1ps
module fir_filter_21tap (
    input clk,
    input rst_n,
    input  signed [15:0] x_in,
    output reg signed [31:0] y_out
);

    // 21 coefficients (signed 16-bit)
    reg signed [15:0] COEFF [0:20];
    integer i;

    // Load coefficients (Q15 format)
    initial begin
        $readmemb("D:/HDLAB/MAINphase1/coeff_bin.txt", COEFF);
        for (i = 0; i < 21; i = i + 1)
            $display("Coeff[%0d] = %0d", i, COEFF[i]);
    end

    // Input shift register
    reg signed [15:0] shift_reg [0:20];
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            for (i = 0; i < 21; i = i + 1)
                shift_reg[i] <= 0;
        else begin
            shift_reg[0] <= x_in;
            for (i = 1; i < 21; i = i + 1)
                shift_reg[i] <= shift_reg[i-1];
        end
    end

    // Multiply-accumulate (32-bit products)
    reg signed [47:0] acc;   // wider accumulator to avoid overflow
    integer k;
    always @(*) begin
        acc = 0;
        for (k = 0; k < 21; k = k + 1)
            acc = acc + (shift_reg[k] * COEFF[k]);
    end

    // Scale down Q15 product (>>15) and register output
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            y_out <= 0;
        else
            y_out <= acc >>> 15;  // correct scaling for Q15 coefficients
    end


endmodule
