`timescale 1ns/1ps

module fir_tb();

    reg clk;
    reg rst_n;
    reg signed [15:0] x_in;
    wire signed [31:0] y_out;

    integer fd, n;
    real fs, t, sine_val;
    reg signed [15:0] xin;

    // Instantiate FIR
    fir_filter_21tap uut (
        .clk(clk),
        .rst_n(rst_n),
        .x_in(x_in),
        .y_out(y_out)
    );

    // Clock: 80 MHz
    initial clk = 0;
    always #6.25 clk = ~clk;

    // Apply sine wave and log output
    task apply_sine;
        input integer fd_task;
        input real freq;
        input integer total_samples;
        integer n;
        begin
            // Reset filter
            rst_n = 0;
            repeat(5) @(posedge clk);
            rst_n = 1;

            for (n = 0; n < total_samples; n = n + 1) begin
                t = n / fs;
                sine_val = $sin(2.0 * 3.1415926535 * freq * t);
                xin = $rtoi(sine_val * 32767); // 16-bit signed input
                x_in = xin;

                @(posedge clk);

                // Log after latency
                if (n >= 21)
                    $fwrite(fd_task, "%0d\t%d\t%d\n", n, x_in, y_out);
            end
        end
    endtask

    initial begin
        fs = 80e6; // 80 MHz sampling

        $display("Starting FIR simulation...");

        // 2 MHz (well within passband)
		fd = $fopen("D:/HDLAB/MAINphase1/fir_output_2MHz.txt", "w");
		apply_sine(fd, 2e6, 512);
		$fclose(fd);

		// 10 MHz (near cutoff)
		fd = $fopen("D:/HDLAB/MAINphase1/fir_output_10MHz.txt", "w");
		apply_sine(fd, 10e6, 512);
		$fclose(fd);

		// 15 MHz (in stopband)
		fd = $fopen("D:/HDLAB/MAINphase1/fir_output_15MHz.txt", "w");
		apply_sine(fd, 15e6, 512);
		$fclose(fd);

        // 30 MHz test
        fd = $fopen("D:/HDLAB/MAINphase1/fir_output_30MHz.txt", "w");
        $fwrite(fd, "Index\tInput\tOutput\n");
        apply_sine(fd, 30e6, 512);
        $fclose(fd);
        $display("30 MHz test done.");

        $display("All simulations complete.");
        $stop;
    end

endmodule
