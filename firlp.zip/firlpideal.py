import numpy as np
from scipy.signal import firwin, freqz, lfilter
import matplotlib.pyplot as plt

# -------------------------------------------------------------
# FIR Filter Specifications
# -------------------------------------------------------------
fs = 80e6         # Sampling frequency (Hz)
fc = 10e6         # Cutoff frequency (Hz)
num_taps = 21     # Number of filter coefficients

# Normalized cutoff frequency
f_n = fc / (fs / 2)

# Generate FIR coefficients using Hamming window
coefficients = firwin(num_taps, f_n, window='hamming')

# Display coefficients
print("FIR Low-Pass Filter Coefficients (Hamming Window):")
for i, c in enumerate(coefficients):
    print(f"h[{i}] = {c:.10f}")

# Save floating-point coefficients
np.savetxt("fir_coefficients.txt", coefficients, fmt="%.10f")

# --- Q15 Fixed-point Conversion (for FPGA/STM32) ---
q15_coeffs = np.round(coefficients * (2**15)).astype(int)
np.savetxt("fir_coefficients_q15.txt", q15_coeffs, fmt="%d")

print("\nQ15 Fixed-Point Coefficients:")
for i, q in enumerate(q15_coeffs):
    print(f"h_q15[{i}] = {q}")

# -------------------------------------------------------------
# Frequency Response (Magnitude)
# -------------------------------------------------------------
w, h = freqz(coefficients, worN=2048)
freq_mhz = (w / np.pi) * (fs / 2) / 1e6

plt.figure(figsize=(8, 5))
plt.plot(freq_mhz, 20 * np.log10(np.abs(h)), color='b')
plt.title("Magnitude Response of 21-Tap FIR LPF (Hamming, Fc = 10 MHz)")
plt.xlabel("Frequency (MHz)")
plt.ylabel("Gain (dB)")
plt.grid(True)
plt.show()

# -------------------------------------------------------------
# Phase Response
# -------------------------------------------------------------
plt.figure(figsize=(8, 5))
plt.plot(freq_mhz, np.unwrap(np.angle(h)) * 180 / np.pi, color='r')
plt.title("Phase Response of 21-Tap FIR LPF (Hamming, Fc = 10 MHz)")
plt.xlabel("Frequency (MHz)")
plt.ylabel("Phase (degrees)")
plt.grid(True)
plt.show()

# -------------------------------------------------------------
# Time-Domain Test for 5 MHz, 10 MHz, and 15 MHz
# -------------------------------------------------------------
test_freqs = [5e6, 10e6, 15e6]
t = np.arange(0, 400e-9, 1/fs)   # simulate 400 ns window (32 samples at 80 MHz)

plt.figure(figsize=(10, 8))

for i, f in enumerate(test_freqs):
    x = np.sin(2 * np.pi * f * t)
    y = lfilter(coefficients, 1.0, x)

    # Find max points
    max_in_idx = np.argmax(x)
    max_out_idx = np.argmax(y)
    max_in_val = x[max_in_idx]
    max_out_val = y[max_out_idx]

    plt.subplot(3, 1, i + 1)
    plt.plot(t * 1e9, x, label=f"Input {f/1e6:.0f} MHz", alpha=0.7)
    plt.plot(t * 1e9, y, label=f"Output {f/1e6:.0f} MHz", linewidth=2)

    # Mark maximum points
    plt.scatter(t[max_in_idx] * 1e9, max_in_val, color='blue', marker='o', s=40, zorder=5)
    plt.scatter(t[max_out_idx] * 1e9, max_out_val, color='red', marker='o', s=40, zorder=5)

    # Annotate values
    plt.text(t[max_in_idx] * 1e9, max_in_val,
             f"In max: {max_in_val:.3f}", color='blue', fontsize=8, va='bottom')
    plt.text(t[max_out_idx] * 1e9, max_out_val,
             f"Out max: {max_out_val:.3f}", color='red', fontsize=8, va='bottom')

    plt.title(f"FIR Filter Response for {f/1e6:.0f} MHz Input (Fc = 10 MHz)")
    plt.xlabel("Time (ns)")
    plt.ylabel("Amplitude")
    plt.grid(True)
    plt.legend()

plt.tight_layout()
plt.show()
