@echo off
cd /d C:\iverilog\bin
del /s /q *.vcd
del /s /q dsn
iverilog -o dsn D:\HDLAB\MAINphase1\fir.v D:\HDLAB\MAINphase1\fir_tb.v > D:\HDLAB\MAINphase1\err.txt 2>&1
vvp dsn
gtkwave fir_tb.vcd
pause


